#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>

#include "Image.h"
#include "Texture.h"

namespace Library
{
	Image::Image(std::string texturePath, TextureSpec& spec)
		: mWidth(0), mHeight(0), mData(nullptr), mImageFormat(ImageFormatRGB)
	{
		int channels;
		if(spec.Type == GL_FLOAT)
        {
             mData = stbi_loadf(texturePath.c_str(), &mWidth, &mHeight, &channels, 0);
            if(channels != spec.Channels)
            {
                float* tData = (float*)malloc(mWidth*mHeight*spec.Channels*sizeof(float));
                for(int i = 0; i < mWidth*mHeight; i++)
                {
                    for(int j = 0; j < spec.Channels; j++)
                    {
                        tData[i*spec.Channels + j] = (j < channels) ? ((float*)mData)[i*channels + j] : 0.0f;
                    }
                }
                free(mData);
                mData = tData;
            }
        }
        else
        {
            mData = stbi_load(texturePath.c_str(), &mWidth, &mHeight, &channels, 0);
            if(channels != spec.Channels)
            {
                unsigned char* tData = (unsigned char*)malloc(mWidth*mHeight*spec.Channels*sizeof(unsigned char));
                for(int i = 0; i < mWidth*mHeight; i++)
                {
                    for(int j = 0; j < spec.Channels; j++)
                    {
                        tData[i*spec.Channels + j] = (j < channels) ? ((unsigned char*)mData)[i*channels + j] : 0;
                    }
                }

                free(mData);
                mData = tData;
            }
        }

		mImageFormat = (ImageFormat)channels;
	}

	Image::~Image()
	{
		stbi_image_free(mData);
	}
	const unsigned char * Image::GetData() const
	{
		return (unsigned char*)mData;
	}
	int Image::Width() const
	{
		return mWidth;
	}
	int Image::Height() const
	{
		return mHeight;
	}

	GLenum Image::Format() const
	{
		switch (mImageFormat)
		{
		case ImageFormatR:
			return GL_R;
		case ImageFormatRG:
			return GL_RG;
		case ImageFormatRGB:
			return GL_RGB;
		case ImageFormatRGBA:
			return GL_RGBA;
		default:
			return 0;
		}
	}
}
