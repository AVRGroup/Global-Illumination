#include "Texture.h"
#include "Image.h"
//#include "Utility.h"


namespace Library
{
	Texture::Texture(int width, int height, TextureType type, TextureFormat format)
		:  mID(0), mTextureType(type), mGLTextureType(GL_TEXTURE_2D)
	{
		/*glGenTextures(1, &mID);
		glBindTexture(GL_TEXTURE_2D, mID);

		if (mTextureType == TextureTypeFramebuffer)
		{
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA16, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, 0);
		}
		else if (mTextureType == TextureTypeShadowMap)
		{
			glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT16, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, 0);
		}

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

		glBindTexture(GL_TEXTURE_2D, 0);*/
	}

	Texture::Texture(const std::string & texturePath, TextureFormat format)
		: mID(0), mTextureType(TextureTypeTexture2D), mTextureFormat(format), mGLTextureType(GL_TEXTURE_2D)
	{

	    TextureSpec spec;
	    FillTextureSpec(spec);
		//Image image(Utility::GetPath(texturePath), spec);
		Image image(texturePath, spec);

		glGenTextures(1, &mID);
		glBindTexture(GL_TEXTURE_2D, mID);

		glTexImage2D(GL_TEXTURE_2D, 0, image.Format(), image.Width(), image.Height(), 0, image.Format(), GL_UNSIGNED_BYTE, image.GetData());
		glGenerateMipmap(GL_TEXTURE_2D);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

		glBindTexture(GL_TEXTURE_2D, 0);
	}

	Texture::Texture(std::string * cubemapPath, TextureFormat format)
		: mID(0), mTextureType(TextureTypeCubemap), mGLTextureType(GL_TEXTURE_CUBE_MAP)
	{
		glGenTextures(1, &mID);
		glBindTexture(GL_TEXTURE_CUBE_MAP, mID);

		for (int i = 0; i < 6; i++)
		{
		    TextureSpec spec;
		    FillTextureSpec(spec);
			//Image image(Utility::GetPath(cubemapPath[i]), spec);
			Image image(cubemapPath[i], spec);

			glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, image.Format(), image.Width(), image.Height(), 0, image.Format(), GL_UNSIGNED_BYTE, image.GetData());
		}

		glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

		glBindTexture(GL_TEXTURE_CUBE_MAP, 0);
	}

	Texture::~Texture()
	{
		glDeleteTextures(1, &mID);
	}

	void Texture::FillTextureSpec(TextureSpec& spec)
	{
        switch(mTextureFormat)
        {
        case TextureFormatRGB:
            spec.Format = GL_RGB;
            spec.Type = GL_UNSIGNED_BYTE;
            spec.InternalFormat = GL_RGB8;
            spec.Channels = 3;
            break;
        case TextureFormatRGBA:
            spec.Format = GL_RGBA;
            spec.Type = GL_UNSIGNED_BYTE;
            spec.InternalFormat = GL_RGBA8;
            spec.Channels = 4;
            break;
        case TextureFormatRGB32F:
            spec.Format = GL_RGB;
            spec.Type = GL_FLOAT;
            spec.InternalFormat = GL_RGB32F;
            spec.Channels = 3;
            break;
        case TextureFormatRGBA32F:
            spec.Format = GL_RGBA;
            spec.Type = GL_FLOAT;
            spec.InternalFormat = GL_RGBA32F;
            spec.Channels = 4;
            break;
        case TextureFormatRGB16F:
            spec.Format = GL_RGB;
            spec.Type = GL_HALF_FLOAT;
            spec.InternalFormat = GL_RGB16F;
            spec.Channels = 3;
            break;
        case TextureFormatRGBA16F:
            spec.Format = GL_RGBA;
            spec.Type = GL_HALF_FLOAT;
            spec.InternalFormat = GL_RGBA16F;
            spec.Channels = 4;
            break;
        case TextureFormatDepth16:
            break;
        case TextureFormatDepth24:
            break;
        case TextureFormatDepth32:
            break;
        }
	}

	TextureType Texture::GetTextureType() const
	{
		return mTextureType;
	}

	void Texture::Use(unsigned int textureUnit)
	{
	    glActiveTexture(GL_TEXTURE0+textureUnit);
		glBindTexture(mGLTextureType, mID);
	}

	void Texture::Release()
	{
		glBindTexture(mGLTextureType, 0);
	}
}
