#pragma once

//#include "Common.h"
#include <string>
#include <vector>
#include <map>
#include <memory>

extern "C" {
    #define GLEW_STATIC
    #include <GL/glew.h>
    #include <GLFW/glfw3.h>
}


namespace Library
{
	enum ImageFormat
	{
		ImageFormatR = 1,
		ImageFormatRG = 2,
		ImageFormatRGB = 3,
		ImageFormatRGBA = 4
	};

	struct TextureSpec;

	class Image
	{
	public:
		Image(std::string texturePath, TextureSpec& spec);
		~Image();

		const unsigned char* GetData() const;
		int Width() const;
		int Height() const;

		GLenum Format() const;

	private:
		int mWidth;
		int mHeight;

		void* mData;

		ImageFormat mImageFormat;


	private:
	};
}
