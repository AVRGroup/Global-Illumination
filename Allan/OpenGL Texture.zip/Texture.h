#pragma once

//#include "Common.h"
#include <string>
#include <vector>
#include <map>
#include <memory>

extern "C" {
    #define GLEW_STATIC
    #include <GL/glew.h>
    #include <GLFW/glfw3.h>
}



namespace Library
{
	enum TextureType
	{
		TextureTypeTexture2D,
		TextureTypeCubemap
	};

	enum TextureFormat
	{
		TextureFormatRGB,
		TextureFormatRGBA,
		TextureFormatRGB32F,
		TextureFormatRGBA32F,
		TextureFormatRGB16F,
		TextureFormatRGBA16F,
		TextureFormatDepth16,
		TextureFormatDepth24,
		TextureFormatDepth32
	};

	struct TextureSpec
	{
        GLint InternalFormat;
        GLenum Format;
        GLenum Type;
        GLint Channels;
	};

	class Image;

	class Texture
	{
	public:
		Texture(int width, int height, TextureType type, TextureFormat format);
		Texture(const std::string& texturePath, TextureFormat format);
		Texture(std::string* cubemapPath, TextureFormat format);
		~Texture();

		TextureType GetTextureType() const;

		void Use(unsigned int textureUnit = 0);
		void Release();

		GLuint ID() const;

	private:
		GLuint mID;
		TextureType mTextureType;
		TextureFormat mTextureFormat;
		GLenum mGLTextureType;

		void FillTextureSpec(TextureSpec& spec);

		Texture(const Texture& rhs);
		Texture& operator=(const Texture& rhs);
	};
}
